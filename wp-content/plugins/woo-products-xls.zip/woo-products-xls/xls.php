<?php
  
require_once ('../../../wp-load.php');
  
// Make sure we don't expose any info if called directly
if ( md5(AUTH_KEY) != $_GET['AUTHKEY'] || !function_exists( 'add_action' )) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}  
  
  
  $wooxls_options   = get_option('wooxls');
  $wooxls_cache     = get_option('wooxls_cache', 'cache_to_sqlite3');
  $wooxls_version   = get_option('wooxls_version', 'xlsx');
  $wooxls_batch     = get_option('wooxls_batch', 50);
  $wooxls_catsplit  = get_option('wooxls_catsplit', '>');
  $wooxls_filesplit = get_option('wooxls_filesplit', 0);
  
  if (!is_array($wooxls_options)) { $wooxls_options = array(); } // check if any field was selected for export
  
  // set the filename
  $file_name =  $_GET['file_name'];
  $xlsreturn = '';
  
  $startpoint = $_GET['startpoint'];
  $pcount = $_GET['pcount'];
  
  
  if ($startpoint == 0) {
    // empty file
    $xlsreturn .= "emptying file<br />\n";
    fclose(fopen($file_name,'w'));
    $fh = fopen($file_name, 'w') or die("Can't create file");
    fclose($fh);
  }
  
  // ********************************************** //
  // Include PHPExcel lib
    /** Error reporting */
    //error_reporting(E_ALL);

    /** Include path **/
    ini_set('include_path', ini_get('include_path').';../Classes/');

    /** PHPExcel */
    include 'PHPExcel.php';

    if ($wooxls_version == 'xlsx') {
      /** PHPExcel_Writer_Excel2007 */
      include 'PHPExcel/Writer/Excel2007.php';
    }

    if ($wooxls_version == 'xls') {
      /** PHPExcel_Writer_Excel2003 */
      include 'PHPExcel/Writer/Excel5.php';
    }
    
    if ($wooxls_cache == 'cache_to_sqlite3') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_sqlite3; }
    if ($wooxls_cache == 'cache_to_sqlite') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_sqlite; }
    if ($wooxls_cache == 'cache_in_memory') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_in_memory; }
    if ($wooxls_cache == 'cache_in_memory_serialized') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_in_memory_serialized; }
    if ($wooxls_cache == 'cache_in_memory_gzip') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_in_memory_gzip; }
    if ($wooxls_cache == 'cache_igbinary') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_igbinary; }
    if ($wooxls_cache == 'cache_to_discISAM') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_discISAM; }
    if ($wooxls_cache == 'cache_to_phpTemp') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_phpTemp; }
    if ($wooxls_cache == 'cache_to_apc') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_apc; }
    if ($wooxls_cache == 'cache_to_memcache') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_memcache; }
    if ($wooxls_cache == 'cache_to_wincache') { $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_wincache; }
    
    PHPExcel_Settings::setCacheStorageMethod($cacheMethod);
    
    // Create new PHPExcel object
    if ($startpoint == 0) {
    
      $xlsreturn .= date('H:i:s') .': ' . __('Create new PHPExcel object', 'wooxls'). "<br />\n";
      $objPHPExcel = new PHPExcel();

      // Set properties
      $xlsreturn .= date('H:i:s') .': '. __('Set properties', 'wooxls')."<br />\n";
      $objPHPExcel->getProperties()->setCreator("Woocommerce Products to XLS");
      $objPHPExcel->getProperties()->setLastModifiedBy("Woocommerce Products to XLS");
      $objPHPExcel->getProperties()->setTitle("Woocommerce Products to XLS");
      $objPHPExcel->getProperties()->setSubject("Woocommerce Products to XLS");
      $objPHPExcel->getProperties()->setDescription("Woocommerce Products to XLS");


      // Add some data
      $xlsreturn .= date('H:i:s') .': '. __('Add some data', 'wooxls')."<br />\n";
      $objPHPExcel->setActiveSheetIndex(0);

      // Rename sheet
      $objSheet = $objPHPExcel->getActiveSheet();
      $xlsreturn .= date('H:i:s') .': '. __('Rename sheet', 'wooxls')."<br />\n";
      $objSheet->setTitle('products');

          
      // Save Excel 2007 file
      $xlsreturn .= date('H:i:s') .': '. __('Write to Excel2007 format', 'wooxls') ."<br />\n";
      if ($wooxls_version == 'xlsx') {
        $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
      }
      if ($wooxls_version == 'xls') {
        $objWriter = new PHPExcel_Writer_Excel5($objPHPExcel);
      }
      
    } else {
      
      $objPHPExcel = PHPExcel_IOFactory::load('./files/'.$file_name);
      $objPHPExcel->setActiveSheetIndex(0);
      $objSheet = $objPHPExcel->getActiveSheet();
      if ($wooxls_version == 'xlsx') {
        $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
      }
      if ($wooxls_version == 'xls') {
        $objWriter = new PHPExcel_Writer_Excel5($objPHPExcel);
      }
      
    }
    
    
    /******************************************************************/ 
  
  global $wpdb;
  
  $query = "SELECT * FROM {$wpdb->posts} p where post_type='product' OR post_type='product_variation' ORDER BY ID LIMIT ". $startpoint .", ". $wooxls_batch ."";
  $posts = $wpdb->get_results($query);
  
  if (empty($posts)) {
    $xlsreturn = __('Currently there are no products available.', 'wooxls');
  } else {
    
    // create header START
    if ($startpoint == 0) {
    
      $wooxls_exportfields = wooxls_wooxls_exportfields();
      
      // put custom attributes at the end of the loop / columns
      if (array_key_exists('custom_attributes', $wooxls_options)) {
        $wooxls_v = $wooxls_options['custom_attributes'];
        unset($wooxls_options['custom_attributes']);
        $wooxls_options['custom_attributes'] = $wooxls_v;
      }
      
      $l = 'A';
      foreach($wooxls_options as $key => $on) {
        $objSheet->setCellValueExplicit($l++ .'1',  __( $wooxls_exportfields[$key], 'wooxls' ), PHPExcel_Cell_DataType::TYPE_STRING);
      }
    }
    // create header END
    $i = $startpoint + 2;
    foreach ( $posts as $post ) {
      $post_id = $post->ID;
      $prodata = array();
      $prometa = array();
      $pro = array();
      
      
      $prodata = get_post( $post_id, ARRAY_A);
      $prometa = get_post_meta( $post_id );
      
      // remove attribue_ prefix from predefined attributes
      if ($prodata['post_type'] == 'product_variation') {
        foreach($prometa as $pmkey => $pmvalue) {
          if (strpos($pmkey, 'pa_') !== FALSE && strpos($pmkey, 'attribute_pa_)') === FALSE) {
            $prometa[str_replace('attribute_', '', $pmkey)] = $prometa[$pmkey];
            unset($prometa[$pmkey]);
          }
        }
        $product_parent_id = wp_get_post_parent_id($post_id);
        
      }
      
      // echo '<pre>';
      // var_dump($wooxls_options);
      // echo '</pre>';
      // exit();
      
      // merge arrays
      $pro = $prodata + $prometa;
      
      if (strpos($pro['post_title'], 'Variation') !== FALSE) {
        $pos1 = strpos($pro['post_title'], ' ');
        $pos2 = strpos($pro['post_title'], ' ', $pos1+1);
        $pos3 = strpos($pro['post_title'], ' ', $pos2+1);

        if ($pos3 !== false) {
            $pro['post_title'] = substr($pro['post_title'], $pos3+1);
        }
      }
      
      
      // get product url/link
      if (array_key_exists('post_url', $wooxls_options)) {
        $thelink = '';
        if ($prodata['post_type'] == 'product_variation') {
          $thelink =  get_permalink($product_parent_id);
        } else {
          $thelink =  get_permalink($post_id);
        }
        $pro['post_url'] = $thelink;
      }
    
      
      
      // get languages names
      if (function_exists('wpml_get_language_information')) {
        if (array_key_exists('wpml', $wooxls_options)) {
          $langvars = array();
          $langvars = wpml_get_language_information( $post_id );
          $pro['wpml'] = $langvars['display_name'];
        }
      }
      
      // get categories names
      if (array_key_exists('product_cat_titles', $wooxls_options)) {
        $terms = array(); // reset terms
        $product_cat_titles = array(); // reset categories names
        if ($prodata['post_type'] == 'product_variation') {
          $terms = get_the_terms( $product_parent_id, 'product_cat' );
        } else {
          $terms = get_the_terms( $post_id, 'product_cat' );
        }
        if (!empty($terms)) {
          foreach ($terms as $term) {
            $product_cat_titles[] = $term->name;
            $pro['product_cat'][] = $term->term_id;
          }
          $pro['product_cat_titles'] = implode(', ', $product_cat_titles);
        }
      }

      
      
      // get categories names path
      if (array_key_exists('product_cat_titles_path', $wooxls_options)) {
        $terms = array(); // reset terms
        $product_cat_titles = array(); // reset categories names
        if ($prodata['post_type'] == 'product_variation') {
          $terms = woo_xls_get_product_categories( $product_parent_id );
        } else {
          $terms = woo_xls_get_product_categories( $post_id );
        }
        if (!empty($terms)) {
          $pro['product_cat_titles_path'] = $terms;
        }
      }
      
      // if WC Vendors plugin is installed // https://wordpress.org/plugins/wc-vendors/
      if (class_exists('WC_Vendors')) {
      
        // get commision
        if (array_key_exists('wcv_commision', $wooxls_options)) {
          $pro['wcv_commision'] = WCV_Commission::get_commission_rate($post_id);
        }
        // get vendor id
        if (array_key_exists('wcv_vendor_id', $wooxls_options)) {
          $pro['wcv_vendor_id'] = WCV_Vendors::get_vendor_from_product($post_id);
        }
        // get vendor nicename
        if (array_key_exists('wcv_vendor_name', $wooxls_options)) {
          $pro['wcv_vendor_name'] = get_the_author_meta('user_nicename', WCV_Vendors::get_vendor_from_product($post_id));
        }
      
      }
      
      // if woo brand // http://codecanyon.net/item/woocommerce-brands/8039481
      if ( class_exists( 'pw_woocommerc_brans_active_plugin' ) ) {
        
        // get the brands
        $bterms = wp_get_post_terms( $post_id, 'product_brand');
        $bids = array();
        $bnames = array();
        foreach ($bterms as $br) {
          $bids[] = $br->term_id;
          $bnames[] = $br->name;
        }
        
        $bids = array_reverse($bids);
        $bnames = array_reverse($bnames);
        
        // get brand id
        if (array_key_exists('woobrand_id', $wooxls_options)) {
          $pro['woobrand_id'] = implode(',', $bids);
        }
        // get brand name
        if (array_key_exists('woobrand_name', $wooxls_options)) {
          $pro['woobrand_name'] = implode(',', $bnames);
        }
        
      }
      
      
      // get product featured image url
      if (array_key_exists('_product_tags', $wooxls_options)) {
      // Get tags
        $tags_array = array();
        $terms = wp_get_post_terms($post_id, 'product_tag');
        foreach ( $terms as $term ) { $tags_array[] = $term->name; }
        if (!empty($tags_array)) {
          $pro['_product_tags'] = implode(',', $tags_array);
        } else {
          $pro['_product_tags'] = '';
        }
      }
      // get product featured image url
      if (array_key_exists('_thumbnail_url', $wooxls_options) && isset($pro['_thumbnail_id'])) {
        $imginfo = '';
        $pro['_thumbnail_url'] = '';
        $imginfo = wp_get_attachment_image_src( $pro['_thumbnail_id'][0], 'full' ); 
        $pro['_thumbnail_url'] = $imginfo[0];
      }
      
      // get product gallery images urls
      if (array_key_exists('_product_image_gallery_urls', $wooxls_options) && isset($pro['_product_image_gallery'])) {
        $imginfo = array();
        $pro['_product_image_gallery_urls'] = '';
        $imginfo = explode(',', $pro['_product_image_gallery'][0]);
        foreach($imginfo as $imgid) {
          $singleimginfo = wp_get_attachment_image_src( $imgid, 'full' ); 
          $pro['_product_image_gallery_urls'][] = $singleimginfo[0];
        }
      }
      
      // add filter for devs to hook.
      $pro = apply_filters('wooxls_product_data_filter', $pro, $post_id);
      
      $l = 'A';
      $cellval = '';
      foreach($wooxls_options as $key => $on) {
        
        if (isset($pro[$key]) && is_array($pro[$key])) {
          $cellval  = implode(',', $pro[$key]);
        } else {
          $cellval = (isset($pro[$key]) ? $pro[$key] : '');
        }
        if (strpos($key, 'pa_') !== FALSE) {
          $attr_terms_array = array();
          $attr_terms = get_the_terms( $post_id, $key);
          if (!empty($attr_terms)) {
            foreach ( $attr_terms as $t ) {
              $attr_terms_array[] = $t->name;
            }
            $cellval = implode(apply_filters( 'wooxls_implodechar_filter', ','), $attr_terms_array);
          }
        }
        
        $cellval = apply_filters( 'wooxls_value_filter', $cellval );
        
        // check if it is a custom attribute that we want to insert
        if ($key == 'custom_attributes' && $prodata['post_type'] == 'product_variation') {
          foreach($prometa as $prometakey => $prometavalue) {
            // check if custom attribute exists on the product
            if(strpos($prometakey, 'attribute_pa_') === FALSE && strpos($prometakey, 'attribute_') !== FALSE) {
              $prometavalue = apply_filters( 'wooxls_value_filter', $prometavalue );
              $objSheet->setCellValueExplicit($l++ .$i, implode(apply_filters( 'wooxls_implodechar_filter', ','), $prometavalue), PHPExcel_Cell_DataType::TYPE_STRING);
            }
          }
        } else {        
          $objSheet->setCellValueExplicit($l++ .$i, $cellval, PHPExcel_Cell_DataType::TYPE_STRING);
        }
      }      
      $i++;
    }

  }
  
  
  
  // auto width
  foreach(range('A',$l) as $columnID) {
    $objSheet->getColumnDimension($columnID) ->setAutoSize(true);
  }
  
  $objWriter->save(str_replace('xls.php', './files/'.$file_name, __FILE__));

  // Echo done
  $xlsreturn .= date('H:i:s') .': '. __('Done writing file','wooxls')."<br />\n";
  $xlsreturn .= '<a href="'.plugins_url().'/'.dirname( plugin_basename( __FILE__ ) ) . '/files/'.$file_name .'">Download Excel File</a>'; 
  echo $xlsreturn;
?>