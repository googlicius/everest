<?php
/*
Plugin Name: Woocommerce Export Products to XLS
Plugin URI: https://www.nitroweb.gr
Description: Plugin to export products to XLS spreadsheet
Author: Spyros Vlachopoulos
Version: 0.5.7
Author URI: https://www.hostivate.com
Text Domain: wooxls
*/

// Make sure we don't expose any info if called directly
if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}


// Load plugin textdomain
add_action( 'plugins_loaded', 'wooxls_load_textdomain' );
function wooxls_load_textdomain() {
  load_plugin_textdomain( 'wooxls', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}



function wooxls_wooxls_exportfields() {
  
  global $wpdb;

  // get available attributes
  $query = "SELECT * FROM ".$wpdb->prefix."woocommerce_attribute_taxonomies";
  $attrib = $wpdb->get_results($query);
  $wooxls_attributes = array();
  if (!empty($attrib)) {
    foreach ( $attrib as $at ) {
      $wooxls_attributes['pa_'.$at->attribute_name] = __($at->attribute_name, 'wooxls');
    }
  }
  
  
  // create array for all the fields we want to export
  $wooxls_exportfields = array(
    'ID' => __('Product id', 'wooxls'),
    'post_author' => __('Author id', 'wooxls'),
    'post_date' => __('publish date', 'wooxls'),
    'post_content' => __('Description - Content', 'wooxls'),
    'post_title' => __('Title', 'wooxls'),
    'post_excerpt' => __('Excerpt', 'wooxls'),
    'post_status' => __('Status', 'wooxls'),
    'post_name' => __('Slug', 'wooxls'),
    'post_url' => __('Url', 'wooxls'),
    'post_modified' => __('Modified date', 'wooxls'),
    'post_parent' => __('Parent product ID', 'wooxls'),
    'guid' => __('guid', 'wooxls'),
    'product_cat' => __('Category IDs', 'wooxls'),
    'product_cat_titles' => __('Categories title', 'wooxls'),
    'product_cat_titles_path' => __('Categories title path', 'wooxls'),
    '_stock' => __('Stock (quantity)', 'wooxls'),
    '_sold_individually' => __('Sold individually', 'wooxls'),
    '_price' => __('Price', 'wooxls'),
    '_sale_price_dates_to' => __('Sales price date to', 'wooxls'),
    '_sale_price_dates_from' => __('Sales price date from', 'wooxls'),
    '_tax_class' => __('Tax class', 'wooxls'),
    '_purchase_note' => __('Purchase note', 'wooxls'),
    '_featured' => __('Featured', 'wooxls'),
    '_weight' => __('Weight', 'wooxls'),
    '_length' => __('Length', 'wooxls'),
    '_width' => __('Width', 'wooxls'),
    '_height' => __('Height', 'wooxls'),
    '_sku' => __('SKU', 'wooxls'),
    '_product_attributes' => __('Products attributes', 'wooxls'),
    '_backorders' => __('Backorders status', 'wooxls'),
    '_manage_stock' => __('Manage stock status', 'wooxls'),
    '_tax_status' => __('Tax status', 'wooxls'),
    '_sale_price' => __('Sales price', 'wooxls'),
    '_regular_price' => __('Regular price', 'wooxls'),
    '_virtual' => __('Virtual status', 'wooxls'),
    '_downloadable' => __('Downloadable status', 'wooxls'),
    'total_sales' => __('Total sales', 'wooxls'),
    '_visibility' => __('Visibility', 'wooxls'),
    '_stock_status' => __('Stock status', 'wooxls'),
    '_thumbnail_id' => __('Thumb ID', 'wooxls'),
    '_thumbnail_url' => __('Featured Image URL', 'wooxls'),
    '_product_image_gallery' => __('Gallery images IDs', 'wooxls'),
    '_product_image_gallery_urls' => __('Gallery images URLs', 'wooxls'),
    '_product_tags' => __('Tags', 'wooxls'),
    'custom_attributes' => __('Custom attributes', 'wooxls')
  );

  if (function_exists('wpml_get_language_information')) {
    $wooxls_exportfields['wpml'] = __('Language', 'wooxls');
  }
  
  if (function_exists('wpseo_auto_load')) {
    $wooxls_exportfields['_yoast_wpseo_focuskw'] = __('Yoast SEO Focus KW', 'wooxls');
    $wooxls_exportfields['_yoast_wpseo_title'] = __('Yoast SEO Title', 'wooxls');
    $wooxls_exportfields['_yoast_wpseo_metadesc'] = __('Yoast SEO Meta Description', 'wooxls');
    // facebook
    $wooxls_exportfields['_yoast_wpseo_opengraph-title'] = __('Yoast SEO Facebook Title', 'wooxls');
    $wooxls_exportfields['_yoast_wpseo_opengraph-description'] = __('Yoast SEO Facebook Description', 'wooxls');
    $wooxls_exportfields['_yoast_wpseo_opengraph-image'] = __('Yoast SEO Facebook Image', 'wooxls');
    $wooxls_exportfields['_yoast_wpseo_meta-robots-noindex'] = __('Yoast SEO Custom Index Status', 'wooxls');
    // twitter
    $wooxls_exportfields['yoast_wpseo_twitter-title'] = __('Yoast SEO Twitter Title', 'wooxls');
    $wooxls_exportfields['yoast_wpseo_twitter-description'] = __('Yoast SEO Twitter Description', 'wooxls');
    $wooxls_exportfields['yoast_wpseo_twitter-image'] = __('Yoast SEO Twitter Image', 'wooxls');
    // Google+
    $wooxls_exportfields['yoast_wpseo_google-plus-title'] = __('Yoast SEO Google+ Title', 'wooxls');
    $wooxls_exportfields['yoast_wpseo_google-plus-description'] = __('Yoast SEO Google+ Description', 'wooxls');
    $wooxls_exportfields['yoast_wpseo_google-plus-image'] = __('Yoast SEO Google+ Image', 'wooxls');
  }

  
  if (class_exists('WC_Vendors')) {
    $wooxls_exportfields['wcv_vendor_id'] = __('Vendor ID', 'wooxls');
    $wooxls_exportfields['wcv_vendor_name'] = __('Vendor Name', 'wooxls');
    $wooxls_exportfields['wcv_commision'] = __('Vendor Commision', 'wooxls');
  }
  
  if ( class_exists( 'pw_woocommerc_brans_active_plugin' ) ) {
    $wooxls_exportfields['woobrand_id'] = __('Brand ID', 'wooxls');
    $wooxls_exportfields['woobrand_name'] = __('Brand Name', 'wooxls');
  }
  
  // add attributes to the data
  $wooxls_exportfields = $wooxls_exportfields + $wooxls_attributes;
  // add filter for devs
  $wooxls_exportfields = apply_filters( 'wooxls_exportfields_filter', $wooxls_exportfields );
  
  return $wooxls_exportfields;
}
add_action('admin_menu', 'woo_xls_options', 100);

function woo_xls_options() {
    add_submenu_page( 'woocommerce', 'Products to XLS', 'Products to XLS', 'manage_options', 'wooxls', 'wooxls_callback' ); 
    add_action( 'admin_init', 'wooxls_register_settings' );
}

// register settings
function wooxls_register_settings(){
  
  $wooxls_exportfields = wooxls_wooxls_exportfields();
  
  register_setting( 'wooxls_group', 'wooxls' ); 
  foreach ($wooxls_exportfields as $key => $wooxls_field) {
    register_setting( 'wooxls_group', 'wooxls_'.$key ); 
  }
  register_setting( 'wooxls_group', 'wooxls_ex_simple'); 
  register_setting( 'wooxls_group', 'wooxls_ex_variable'); 
  register_setting( 'wooxls_group', 'wooxls_version'); 
  register_setting( 'wooxls_group', 'wooxls_cache'); 
  register_setting( 'wooxls_group', 'wooxls_batch'); 
  register_setting( 'wooxls_group', 'wooxls_fileplit'); 
  register_setting( 'wooxls_group', 'wooxls_catsplit'); 
}

function wooxls_callback() {
  global $wpdb;
  
  $wooxls_exportfields = wooxls_wooxls_exportfields();
  
  if (isset($_GET['wooxls-export'])) {
    if (get_option('wooxls_version') == 'xlsx') {
      $xlsreturn = '<a href="'.plugins_url().'/'.dirname( plugin_basename( __FILE__ ) ) . '/files/'.$_GET['file'] .'.xlsx">'. __('Download Excel File', 'wooxls') .'</a>'; 
    }
    if (get_option('wooxls_version') == 'xls') {
      $xlsreturn = '<a href="'.plugins_url().'/'.dirname( plugin_basename( __FILE__ ) ) . '/files/'.$_GET['file'] .'.xls">'. __('Download Excel File', 'wooxls') .'</a>'; 
    }
    $files = glob(plugin_dir_path( __FILE__ ).'*.xls');
    foreach($files as $file){ // iterate files
      if(is_file($file))
        unlink($file); // delete file
    }
    $files = glob(plugin_dir_path( __FILE__ ).'*.xlsx');
    foreach($files as $file){ // iterate files
      if(is_file($file))
        unlink($file); // delete file
    }
  }
  if (isset($_GET['wooxls-delete-cache'])) {
    $files = glob(plugin_dir_path( __FILE__ ).'files/*'); // get all file names
    foreach($files as $file){ // iterate files
      if(is_file($file))
        unlink($file); // delete file
    }
  }
  
?>
    <div class="wrap">
      <h2><?php _e('Woocommerce Export Products to XLS', 'wooxls'); ?></h2>
<?php if (isset($_GET['wooxls-export'])) { ?>
      <div class="wooxls-updated">
        <p><strong><?php echo $xlsreturn; ?></strong></p>
      </div>
<?php } ?>
<?php if (isset($_GET['wooxls-delete-cache'])) { ?>
      <div class="wooxls-updated">
        <p><strong><?php _e('All cached XLSX files has been deleted!', 'wooxls'); ?></strong></p>
      </div>
<?php } ?>
      <div class="wooxls-updated">
        <p><strong><?php _e('Please check the data you want to export and drag the rows to order the columns of the exported XLS.', 'wooxls'); ?></strong></p>
        <p><small><?php _e('Custom attributes will always go to the last columns', 'wooxls'); ?></small></p>
      </div>
      <form method="post" action="options.php">
        <?php settings_fields( 'wooxls_group' ); ?>
        <?php do_settings_sections( 'wooxls_group' ); ?>
        
        <?php
                  
          $regoptions         = get_option('wooxls');
          $wooxls_ex_simple   = get_option('wooxls_ex_simple', 0);
          $wooxls_ex_variable = get_option('wooxls_ex_variable', 0);
          $wooxls_version     = get_option('wooxls_version');
          $wooxls_catsplit    = get_option('wooxls_catsplit', '>');
          $wooxls_cache       = get_option('wooxls_cache');
          $wooxls_batch       = get_option('wooxls_batch', 50);
          $wooxls_fileplit    = get_option('wooxls_fileplit', 0);
          
          
          // sort array by previous saved sorting
          if (!empty($regoptions)) {
            $wooxls_exportfields = array_merge($regoptions, $wooxls_exportfields);
          }
          
          echo '<div class="action-buttons">';
          submit_button(__('Save Changes', 'wooxls')); 
          echo '&nbsp;&nbsp;&nbsp;'; 
          // echo '<a href="admin.php?page=wooxls&wooxls-export=true" class="button button-large button-action">'. __('Export to XLS', 'wooxls') .'</a>'; 
          echo '<a href="#gencounter" class="genxlsbtn button button-large button-action">'. __('Export to XLS', 'wooxls') .'</a>'; 
          echo '&nbsp;&nbsp;&nbsp;'; 
          echo '<a href="admin.php?page=wooxls&wooxls-delete-cache=true" class="button button-large button-danger">'. __('Delete cached XLS files', 'wooxls') .'</a>'; 
          echo '</div>';
          echo '
          <p><label class="wooxls_label" for="selectall"><input type="checkbox" id="selectall"/> '. __('Select All', 'wooxls') .'</label></p>
          <ul class="fieldslist sortablelist">';
          foreach ($wooxls_exportfields as $key => $sm) {
            if (!isset($regoptions[$key])) { $regoptions[$key] = 'off'; }
            echo '<li class="wooxls-item ui-state-default">
                <label class="wooxls_label" for="wooxls_'. $key .'">
                <input id="wooxls_'. $key .'" type="checkbox" name="wooxls['.$key.']" value="on" '. ($regoptions[$key] == 'on' ? 'checked="checked"' : '') .'" />
                '. $sm .'</label> 
              </li>';
          }
          echo '</ul>';
          
          
          // options
          
          echo '
          <div class="fieldwrap">
            <label class="vm_label" for="wooxls_ex_simple">'. __('Exclude Simple Products', 'wooxls') .'</label>
            <select name="wooxls_ex_simple" id="wooxls_ex_simple">
              <option value="0" '. ($wooxls_ex_simple == '0' ? 'selected="selected"' : '') .'>'. __('No', 'wooxls') .'</option>
              <option value="1" '. ($wooxls_ex_simple == '1' ? 'selected="selected"' : '') .'>'. __('Yes', 'wooxls') .'</option>
            </select>
          </div>
            <hr />
          ';
          
          echo '
          <div class="fieldwrap">
            <label class="vm_label" for="wooxls_ex_variable">'. __('Exclude Variable Products', 'wooxls') .'</label>
            <select name="wooxls_ex_variable" id="wooxls_ex_variable">
              <option value="0" '. ($wooxls_ex_variable == '0' ? 'selected="selected"' : '') .'>'. __('No', 'wooxls') .'</option>
              <option value="1" '. ($wooxls_ex_variable == '1' ? 'selected="selected"' : '') .'>'. __('Yes', 'wooxls') .'</option>
            </select>
          </div>
            <hr />
          ';
          
          
          echo '
          <div class="fieldwrap">
            <label class="vm_label" for="wooxls_version">'. __('Select Version', 'wooxls') .'</label>
            <select name="wooxls_version" id="wooxls_version">
              <option value="xlsx" '. ($wooxls_version == 'xlsx' ? 'selected="selected"' : '') .'>'. __('xlsx', 'wooxls') .'</option>
              <option value="xls" '. ($wooxls_version == 'xls' ? 'selected="selected"' : '') .'>'. __('xls', 'wooxls') .'</option>
            </select>
          </div>
            <hr />
          ';
          
          echo '
          <div class="fieldwrap">
            <label class="vm_label" for="wooxls_cache">'. __('Select Caching Method', 'wooxls') .'</label>
            <select name="wooxls_cache" id="wooxls_cache">
              <option value="cache_to_sqlite3" '. ($wooxls_cache == 'cache_to_sqlite3' ? 'selected="selected"' : '') .'>'. __('sqlite3', 'wooxls') .'</option>
              <option value="cache_to_sqlite" '. ($wooxls_cache == 'cache_to_sqlite' ? 'selected="selected"' : '') .'>'. __('sqlite', 'wooxls') .'</option>
              <option value="cache_in_memory" '. ($wooxls_cache == 'cache_in_memory' ? 'selected="selected"' : '') .'>'. __('memory', 'wooxls') .'</option>
              <option value="cache_in_memory_serialized" '. ($wooxls_cache == 'cache_in_memory_serialized' ? 'selected="selected"' : '') .'>'. __('memory_serialized', 'wooxls') .'</option>
              <option value="cache_in_memory_gzip" '. ($wooxls_cache == 'cache_in_memory_gzip' ? 'selected="selected"' : '') .'>'. __('memory_gzip', 'wooxls') .'</option>
              <option value="cache_igbinary" '. ($wooxls_cache == 'cache_igbinary' ? 'selected="selected"' : '') .'>'. __('igbinary', 'wooxls') .'</option>
              <option value="cache_to_discISAM" '. ($wooxls_cache == 'cache_to_discISAM' ? 'selected="selected"' : '') .'>'. __('discISAM', 'wooxls') .'</option>
              <option value="cache_to_phpTemp" '. ($wooxls_cache == 'cache_to_phpTemp' ? 'selected="selected"' : '') .'>'. __('phpTemp', 'wooxls') .'</option>
              <option value="cache_to_apc" '. ($wooxls_cache == 'cache_to_apc' ? 'selected="selected"' : '') .'>'. __('apc', 'wooxls') .'</option>
              <!-- <option value="cache_to_memcache" '. ($wooxls_cache == 'cache_to_memcache' ? 'selected="selected"' : '') .'>'. __('memcache', 'wooxls') .'</option> -->
              <!-- <option value="cache_to_wincache" '. ($wooxls_cache == 'cache_to_wincache' ? 'selected="selected"' : '') .'>'. __('wincache', 'wooxls') .'</option> -->
            </select>
            &nbsp;<a href="https://github.com/PHPOffice/PHPExcel/blob/develop/Documentation/markdown/Overview/04-Configuration-Settings.md" title="'. __('More Information', 'wooxls') .'" target="_blank">
              '. __('More Information', 'wooxls') .'
              </a>
            
          </div>
            <hr />
          ';
          
          echo '
          <div class="fieldwrap">
            <label class="vm_label" for="wooxls_batch">'. __('Number of products in one batch', 'wooxls') .'</label>
            <input type="number" name="wooxls_batch" id="wooxls_batch" value="'. $wooxls_batch .'">
          </div>
            <hr />
          ';
          
          /*
          echo '
          <div class="fieldwrap">
            <label class="vm_label" for="wooxls_fileplit">'. __('Create a new XLS file every', 'wooxls') .'</label>
            <input type="number" name="wooxls_fileplit" id="wooxls_fileplit" step="'. $wooxls_batch .'" value="'. $wooxls_fileplit .'"> '. __('products', 'wooxls') .'<br />
            <small>'. __('Enter <strong>0 (zero)</strong> to create <strong>one</strong> file with all products. <strong>Else enter a number that when divided with the batch number above, it equals an integer!</strong>', 'wooxls') .'</small>
          </div>
            <hr />
          ';
          */
          
          echo '
          <div class="fieldwrap">
            <label class="vm_label" for="wooxls_catsplit">'. __('Character(s) to use in order to join the categories path', 'wooxls') .'</label>
            <input type="text" name="wooxls_catsplit" id="wooxls_catsplit" value="'. ($wooxls_catsplit == '' ? '>' : $wooxls_catsplit) .'">
          </div>
            <hr />
          ';
          
          echo '<div class="action-buttons">';
          submit_button(__('Save Changes', 'wooxls')); 
           echo '&nbsp;&nbsp;&nbsp;'; 
          // echo '<a href="admin.php?page=wooxls&wooxls-export=true" class="button button-large button-action">'. __('Export to XLS', 'wooxls') .'</a>'; 
          echo '<a href="#gencounter" class="genxlsbtn button button-large button-action">'. __('Export to XLS', 'wooxls') .'</a>'; 
          echo '&nbsp;&nbsp;&nbsp;'; 
          echo '<a href="admin.php?page=wooxls&wooxls-delete-cache=true" class="button button-large button-danger">'. __('Delete cached XLS files', 'wooxls') .'</a>'; 
          echo '</div>';
          
        ?>
        
        <?php
          $createwhere = array();
          if ($wooxls_ex_simple !=1 ) { $createwhere[] = " post_type='product' "; };
          if ($wooxls_ex_variable !=1 ) { $createwhere[] = " post_type='product_variation' "; };
          
          $pcount = 0;
          if (!empty($createwhere)) {
            $pcount = $wpdb->get_var( "SELECT COUNT(*) FROM $wpdb->posts WHERE ". implode(' OR ', $createwhere) ." ORDER BY ID" );
          }
          $filename = date('YmdHis');
        ?>
      <hr />
      <a name="gencounter"></a> 
      <div id="pleasewait" class="creatingloading"><h4><?php _e('Please wait as the xls is generated. Do <strong>not</strong> close this tab until the file has been generated!', 'wooxls'); ?></h4></div>
      <div id="generator" style="width: 100%; height: 24px; position: relative; background-color: #f9f9f9; padding: 8px 0 4px 0;">
        <div id="progpercent" style="font-size: 28px; position: absolute; top: 5px; left: 5px; z-index: 10"><span>0</span>%</div>
        <div id="progbar" style="width: 0%; height: 36px; position: absolute; top: 0; background-color: #DFF0D8;"></div>
        <div style="width: 100%; height: 32px; text-align: center; position: absolute;""><?php echo __('generated', 'wooxls'); ?> <span class="pcount">0</span> of <?php echo $pcount .' '. __('products', 'wooxls'); ?> <span class="errorcount"></span><span class="creatingloading"><img src="<?php echo plugins_url( 'images/ajax-loader.gif', __FILE__ ); ?>" /></span></div>
      </div>
      </form>
      <hr />
      <h3><?php _e('Cached files', 'wooxls'); ?></h3>
      <hr />
      <div class="filelistcache">
      <ul class="allcachedfiles">
        <li><h3>XLSX</h3></li>
      <?php
        $filelist = glob(plugin_dir_path( __FILE__ ).'files/*.xlsx');
        foreach($filelist as $file) {
          echo '<li>'. date('Y-m-d H:i:s', strtotime(str_replace('.xlsx', '', basename($file)))) .': <a href="'.plugins_url().'/'.dirname( plugin_basename( __FILE__ ) ) . '/files/'. basename($file) .'">'. basename($file) .'</a></li>';
        }
        echo '<li><h3>XLS</h3></li>';
        $filelist = glob(plugin_dir_path( __FILE__ ).'files/*.xls');
        foreach($filelist as $file) {
          echo '<li>'. date('Y-m-d H:i:s', strtotime(str_replace('.xls', '', basename($file)))) .': <a href="'.plugins_url().'/'.dirname( plugin_basename( __FILE__ ) ) . '/files/'. basename($file) .'">'. basename($file) .'</a></li>';
        }
      ?>
      </ul>
      </div>
    </div>
    <style>
      .wooxls_label { display: inline-block; width: 390px; }
      .wooxls-item { margin-bottom: 3px; padding-bottom: 3px; border-bottom: 1px solid #ccc; cursor: move; }
      .wooxls-item select, .wooxls-item input[type="text"] { min-width: 200px; }
      .wooxls-updated {
        margin: 5px 0 15px;
        border-left: 4px solid #7AD03A;
        padding: 1px 12px;
        background-color: #FFF;
        -webkit-box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.1);
        box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.1);
      }
      .action-buttons p { display: inline; }
      .button.button-action { background: #5CB85C; border-color: #4CAE4C; color: #ffffff; font-weight: bold; -webkit-box-shadow: none; 	-moz-box-shadow: none; box-shadow: none; }
      .button.button-action:hover { background: #449D44; border-color: #398439; color: #ffffff;  }
      .button.button-danger { background: #D9534F; border-color: #D43F3A; color: #ffffff; -webkit-box-shadow: none; 	-moz-box-shadow: none; box-shadow: none; }
      .button.button-danger:hover { background: #C9302C; border-color: #AC2925; color: #ffffff; }
      .button.button-warning { padding-left: 25px; padding-right: 25px; font-weight: bold; background: #F0AD4E; border-color: #EEA236; color: #ffffff; -webkit-box-shadow: none; 	-moz-box-shadow: none; box-shadow: none; }
      .button.button-warning:hover { background: #EC971F; border-color: #D58512; color: #ffffff; }      
      li.wooxls-item:hover, li.wooxls-item:focus { background-color: rgba(255,255,255, 0.8); }
      .errorcount { color: #dd0000; }
      .creatingloading, #pleasewait { display: none; }
      .ui-state-highlight { background-color: #FFFFEF; padding: 15px; }
      .vm_label { display: inline-block; width: 250px; }
    </style>
    <script>
      jQuery(document).ready(function(){
        jQuery( ".sortablelist" ).sortable({
          placeholder: "ui-state-highlight",
          change: function(event, ui) {
            jQuery('.action-buttons a.button').fadeOut(200);
            jQuery('input#submit').addClass('button-warning');
          }
        });
        jQuery( ".sortablelist" ).disableSelection();
        // select/deselect all
        jQuery('#selectall').click(function(event) {
          if(this.checked) {
            jQuery('.sortablelist .wooxls-item input').each(function() {
              this.checked = true;     
            });
          }else{
            jQuery('.sortablelist .wooxls-item input').each(function() {
              this.checked = false;               
            });         
          }
        });
        jQuery('.sortablelist .wooxls-item input').click(function() {
          jQuery('.action-buttons a.button').fadeOut(200);
          jQuery('input#submit').addClass('button-warning');
        });
        jQuery('#wooxls_cache, #wooxls_version, #wooxls_batch, #wooxls_catsplit, #wooxls_fileplit, #wooxls_ex_simple, #wooxls_ex_variable').change(function() {
          jQuery('.action-buttons a.button').fadeOut(200);
          jQuery('input#submit').addClass('button-warning');
        });
      });
    </script>
    <script>
      jQuery(document).ready(function(){
        
        var start = 0;
        var splitfile = 0;
        var total = <?php echo $pcount; ?>;
        var errors = 0;
        var filename = '<?php echo $filename.($wooxls_version == 'xlsx' ? '.xlsx' : '.xls'); ?>'
        var generator = '<?php echo plugins_url( 'xls.php', __FILE__ ); ?>';
        var AUTH_KEY = '<?php echo md5(AUTH_KEY); ?>';
        
        jQuery(".genxlsbtn").click(function(){
          start = 0;
          // splitfile = <?php echo $wooxls_fileplit; ?>;
          total = <?php echo $pcount; ?>;
          jQuery('.creatingloading').show();
          jQuery('.action-buttons').fadeOut(200);
          createxls (start);          
        });
      
      
      function createxls (start){
          jQuery.get( ''+ generator +'', { file_name: ''+ filename +'', AUTHKEY: ''+ AUTH_KEY +'', startpoint: start, pcount: total } )
            .done(function( data ) {
            start = start + <?php echo $wooxls_batch; ?>;
            
            jQuery('.pcount').text(start - errors);
            console.log('success on id: ' + data);
            // console.log(data);
            if (start < total) {
              jQuery('#progbar').css({'width': Math.round(100 * (start - errors) / total) +'%'});
              jQuery('#progpercent span').text(Math.round(100 * (start - errors) / total));
              createxls(start);
            } else {
              jQuery('.creatingloading').hide();
              jQuery('.pcount').text(total - errors);
              window.location.href = window.location.href.split('?')[0] +"?page=wooxls&wooxls-export=1&file=<?php echo $filename;?>";
            }
          })
          .fail(function(data) {
            start = start + <?php echo $wooxls_batch; ?>;
            errors = errors + <?php echo $wooxls_batch; ?>;
            jQuery('.pcount').text(start - errors);
            jQuery('.errorcount').text('Skipped: ' + errors);
            console.log('error on id: ' + data);
            if (start < total) {
              jQuery('#progbar').css({'width': Math.round(100 * (start - errors) / total) +'%'});
              jQuery('#progpercent span').text(Math.round(100 * (start - errors) / total));
              createxls(start);
            } else {
              jQuery('.creatingloading').hide();
              jQuery('.pcount').text(total - errors);
              window.location.href = window.location.href.split('?')[0] +"?page=wooxls&wooxls-export=1&file=<?php echo $filename;?>";
            }
          });
        }
      });
      </script>
<?php
}

function wooxls_load_admin_scripts () {

  if (isset($_GET['page']) && $_GET['page'] == 'wooxls') {
    wp_enqueue_script("jquery-ui-core");
    wp_enqueue_script("jquery-ui-sortable");
    wp_enqueue_script("jquery-ui-draggable");
    wp_enqueue_script("jquery-ui-droppable");
  }
  
}
add_action("admin_enqueue_scripts", "wooxls_load_admin_scripts");


// Add settings link on plugin page
function wooxls_plugin_settings_link($links) { 
  $settings_link = '<a href="admin.php?page=wooxls">'. __('Settings', 'wooxls') .'</a>'; 
  array_unshift($links, $settings_link); 
  return $links; 
}
 
$wooxls_plugin = plugin_basename(__FILE__); 
add_filter("plugin_action_links_$wooxls_plugin", 'wooxls_plugin_settings_link' );



// get all parent categories
function get_parent_terms($term) {
    if ($term->parent > 0) {
        $term = get_term_by("id", $term->parent, "product_cat");
        if ($term->parent > 0) {
            get_parent_terms($term);
        } else return $term;
    }
    else return $term;
}

# Will return all categories of a product, including parent categories
/* function woo_xls_get_product_categories($postid) {
  
    $split = get_option('wooxls_catsplit', '>');
  
    if ($split == '') { $split = '>'; }
  
    $cats = array(); 
    $terms = get_the_terms($postid, "product_cat");
    $key = 0;

    // foreach product_cat get main top product_cat
    $i = 0;
    foreach ($terms as $cat) {
        if ($i == 0) { $catname = $cat->name; $i++; }
        $cat = get_parent_terms($cat);
        $cats[] = (!in_array($cat->name, $cats) ? $cat->name : "");
        $key++;
    }
    
    if (!in_array($catname, $cats)) {
      $cats[] = $catname;
    }
    
    return rtrim($split, implode($split, $cats));
} */


//display parent categories for each category on a post--must be used in the loop
function woo_xls_get_product_categories($postid) {
    global $woocommerce;
    
    $split = get_option('wooxls_catsplit', '>');
    $out = array();
    $i = 0;
    $parcats = array();
    
    if ($split == '') { $split = '>'; }
    

    $terms = wc_get_product_terms( $postid, 'product_cat', array( 'orderby' => 'parent', 'order' => 'DESC' ) );
    if ( ! empty( $terms ) ) {
        $main_term = $terms[0];
        $ancestors = get_ancestors( $main_term->term_id, 'product_cat' );
        if ( ! empty( $ancestors ) ) {
            $ancestors = array_reverse( $ancestors );
            // first element in $ancestors has the root category ID
            // get root category object
            $root_cat = get_term( $ancestors[0], 'product_cat' );
        }
        else {
            // root category would be $main_term if no ancestors exist
        }
    }
    else {
        // no category assigned to the product
    }
    $ancestors[] = $main_term->term_id;
    if ($ancestors) {
      foreach ($ancestors as $parent) {
        $category = get_term_by('id',$parent, 'product_cat');
        $parcats[] = $category->name;
      }
      $parcats = implode($split, $parcats);
    }
    
    return  $parcats;
}

?>